# Premium ExcellentCrates Survival Pack

This pack was built around the modern ExcellentCrates multi-file structure:

- config.yml
- crates/*.yml
- keys/*.yml
- previews/*.yml
- openings/inventory/*.yml
- lang/messages_en.yml

## Notes

- Money rewards assume EssentialsX-style economy commands: `eco give <player> <amount>`.
- All keys are physical keys.
- All crate block positions are intentionally empty; link them in-game with the editor/link tool.
- Holograms require ProtocolLib or PacketEvents to render in ExcellentCrates 6.6.x.
- Progression: vote → common → iron → gold → diamond → epic → mystery → legendary.

## Install

Copy the contents of this folder into your server's `plugins/ExcellentCrates/` directory.
